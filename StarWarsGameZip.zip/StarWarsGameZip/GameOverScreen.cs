using Godot;
using System;

public partial class GameOverScreen : Control
{
    public override void _Ready()
    {
        GetTree().Paused = true;
    }
}
