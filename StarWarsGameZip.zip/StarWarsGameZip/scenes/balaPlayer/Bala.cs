using Godot;
using System;

public partial class Bala : Area2D
{
	private float velocidadBala = 100f;
	private Vector2 direccion = Vector2.Right;
	private AnimatedSprite2D animated_Bala;
	private int damage = 5;

	public override void _Ready()
	{
        animated_Bala = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		BodyEntered += Disparado;
    }

	public override void _Process(double delta)
	{
        Position += direccion * velocidadBala * (float)delta;
		animated_Bala.Play("default");
        if (Position.X < -100 || Position.X > 1500) { QueueFree(); }

    }

	public void Disparado(Node2D cuerpo)
	{
		if (cuerpo is  Boss enemigo)
		{
			enemigo.RecibirDamage(damage);
			QueueFree();
		}

		else if (cuerpo is TileMapLayer tilemap)
		{
			QueueFree();
		}
	}
}
