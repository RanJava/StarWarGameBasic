using Godot;
using System;
using System.Threading.Tasks;

public partial class Boss : CharacterBody2D
{
    [Export] public PackedScene BalaBossEscena;
    [Export] public PackedScene RayoBossEscena;
    [Export] public PackedScene BolitaBossEscena;


    //Bala
    private Sprite2D animates_sprites;
    private Timer tiempoDeAtaque;
    private float disparo1 = 0.9f;


    //Rayo
    private Timer tiempoRayo;
    private Marker2D ojos;
    private float dispara2 = 10.0f;

    //Bolitas
    private float disparo3 = 5.0f;
    private Timer tiempoDeBolita;
    private Marker2D bolitaMarker;


    //Boss
    private int vida = 50;
    private int vidaActual;

   //ProgressBar
    private ProgressBarBoss barraDeVidaZombie;
    private const string WinPath = "res://scenes/win_screen.tscn";


    public override void _Ready()
    {
        //Ataque BASE
        tiempoDeAtaque = GetNode<Timer>("AttackTimer");
        tiempoDeAtaque.WaitTime = disparo1;
        tiempoDeAtaque.Timeout += TimerAtaque;
        tiempoDeAtaque.Start();

        //Ataque RAYO
        ojos = GetNode<Marker2D>("Marker2D");
        tiempoRayo = GetNode<Timer>("RayoTimer");
        tiempoRayo.WaitTime = dispara2;
        tiempoRayo.Timeout += LaserAtaque;
        tiempoRayo.Start();

        //Ataque Bolita
        bolitaMarker = GetNode<Marker2D>("BolitaMarker2D");
        tiempoDeBolita = GetNode<Timer>("BolitaTimer");
        tiempoDeBolita.WaitTime = disparo3;
        tiempoDeBolita.Timeout += BolitaAtaque;
        tiempoDeBolita.Start();


        animates_sprites = GetNode<Sprite2D>("Sprite2DDroidkea");
        vidaActual = vida;

        barraDeVidaZombie = GetNode<ProgressBarBoss>("ProgressBarBoss");
        barraDeVidaZombie.ActualizarBarraZombie(vida, vidaActual);
    }

    private void TimerAtaque()
    {
        Atacar();
        tiempoDeAtaque.Start();
        animates_sprites.Modulate = new Color(1, 1, 1, 1);

    }

    private void LaserAtaque()
    {
        AtacarRayo();
        tiempoRayo.Start();
    }

    private void BolitaAtaque()
    {
        AtacarBolita();
        tiempoDeBolita.Start();
    }

    private void AtacarBolita()
    {
        Bolita bola = BolitaBossEscena.Instantiate<Bolita>();
        bola.Position = bolitaMarker.GlobalPosition;
        GetTree().CurrentScene.AddChild(bola);
    }

    private async Task AtacarRayo()
    {
        RayoBoss rayo = RayoBossEscena.Instantiate<RayoBoss>();
        rayo.Position = ojos.GlobalPosition;
        GetTree().CurrentScene.AddChild(rayo);
        await Task.Delay(5000);
        GetTree().CurrentScene.RemoveChild(rayo);
    }

    private void Atacar()
    {
        BalaBoss bala = BalaBossEscena.Instantiate<BalaBoss>();
        bala.Position = GlobalPosition;
        GetTree().CurrentScene.AddChild(bala);
    }

    public void RecibirDamage(int damage)
    {
        vidaActual -= damage;
        barraDeVidaZombie.ActualizarBarraZombie(vida, vidaActual);

        if (vidaActual <= 0)
        {
            Morir();
        }
        else
        {
            animates_sprites.Modulate = new Color(1, 0.5f, 0.5f, 0.5f);
        }
    }

    private void Morir()
    {
        tiempoDeAtaque.Stop();
        tiempoRayo.Stop();
        tiempoDeBolita.Stop();

        foreach (Node child in GetTree().CurrentScene.GetChildren())
        {
            if (child is RayoBoss rayo)
            {
                rayo.QueueFree();
            }
        }

        var winScene = GD.Load<PackedScene>(WinPath);
        var winInstance = winScene.Instantiate();
        GetTree().Root.AddChild(winInstance);
        QueueFree();
    }

}