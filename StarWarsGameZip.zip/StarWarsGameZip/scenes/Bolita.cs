using Godot;
using System;

public partial class Bolita : Area2D
{
	private float velocidad = 100f;
	private int damage = 2;
	private Vector2 direccion = Vector2.Left;
	private AnimatedSprite2D animatedSprite;
	public override void _Ready()
	{
		animatedSprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		BodyEntered += Disparado;
	}

	public override void _Process(double delta)
	{
        Position += direccion * velocidad * (float)delta;
        animatedSprite.Play("run");
        if (Position.X < -100 || Position.X > 1500) { QueueFree(); }
    }

	public void Disparado(Node2D cuerpo)
	{
		if (cuerpo is Player player)
		{
			player.RecibirDano(damage);
			QueueFree();
		}

        else if (cuerpo is TileMapLayer tilemap)
        {
            QueueFree();
        }
    }
}
