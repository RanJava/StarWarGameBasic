using Godot;
using System;

public partial class RayoBoss : Area2D
{
	private int damage = 4;
	public override void _Ready()
	{
        BodyEntered += Disparado;
	}

    private void Disparado(Node2D cuerpo)
    {
        if (cuerpo is Player jugador)
        {
            jugador.RecibirDano(damage);
        }
    }
}
