using Godot;
using System;
using static Godot.TextServer;

public partial class Player : CharacterBody2D
{
	public const float Speed = 170.0f;
	public const float JumpVelocity = -350.0f;
	public bool esta_viendo_Izquierda = true;
    private AnimatedSprite2D animates_sprites;
    private float tiempoRecarga = 1.3f;
    private double tiempoUltimo = 0;

    [Export] public PackedScene BalaScene;
    private int vidaMaxima = 15;
    private float duracionInvulnerabilidad = 0.9f;

    private int vidaActual;
    private bool Invulnerable = false;
    private Timer temporizadorInvulnerabilidad;
    private ProgressBar barraDeVida;

    private const string GameOverScenePath = "D:/UPDS/SEMESTRE IV/ProgramacionIII/Proyecto/fase-1/scenes/game_over_screen.tscn";

    public override void _Ready()
    {
        animates_sprites = GetNode<AnimatedSprite2D>("Sprite2D");

        vidaActual = vidaMaxima;
        temporizadorInvulnerabilidad = GetNode<Timer>("TemporizadorInvulnerabilidad");
        temporizadorInvulnerabilidad.Timeout += TerminarInvulnerabilidad;

        barraDeVida = GetNode<ProgressBar>("ProgressBar");
        barraDeVida.ActualizarBarra(vidaActual, vidaMaxima);
    }
    public override void _PhysicsProcess(double delta)
	{

        Vector2 velocity = Velocity;
		if (!IsOnFloor())
		{
			velocity += GetGravity() * (float)delta;
		}

		float directionX = Input.GetAxis("mover_left", "mover_right");
        if (directionX != 0)
        {
            animates_sprites.Play("run");
            velocity.X = directionX * Speed;
            if (directionX < 0 && !esta_viendo_Izquierda)
            {
                Scale = new Vector2(-Scale.X, Scale.Y);
                esta_viendo_Izquierda = true;
            }
            else if (directionX > 0 && esta_viendo_Izquierda)
            {
                Scale = new Vector2(-Scale.X, Scale.Y);
                esta_viendo_Izquierda = false;
            }

        }
        else
        {
            velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed);
            animates_sprites.Play("idle");
        }

        if (Input.IsActionJustPressed("mover_up") && IsOnFloor())
        {
            velocity.Y = JumpVelocity;
        }

        tiempoUltimo += delta;
        if (Input.IsActionPressed("disparar") && tiempoUltimo >= tiempoRecarga)
        {
            Disparar();
            tiempoUltimo = 0;
        }

        Velocity = velocity;
		MoveAndSlide();
	}

    public void RecibirDano(int damage)
    {
        if (Invulnerable) return;

        vidaActual -= damage;
        barraDeVida.ActualizarBarra(vidaMaxima, vidaActual);
        if (vidaActual <= 0)
        {
            Morir();
        }
        else
        {
            Invulnerable = true;
            animates_sprites.Modulate = new Color(1, 0.5f, 0.5f, 0.5f);
            temporizadorInvulnerabilidad.Start(duracionInvulnerabilidad);
        }
    }

    private void TerminarInvulnerabilidad()
    {
        Invulnerable = false;
        animates_sprites.Modulate = new Color(1, 1, 1, 1);
    }

    private void Morir()
    {
        QueueFree();
        var gameOverScene = GD.Load<PackedScene>(GameOverScenePath);
        var gameOverInstance = gameOverScene.Instantiate();
        GetTree().Root.AddChild(gameOverInstance);
    }

    private void Disparar()
    {
        Bala bala = BalaScene.Instantiate<Bala>();
        bala.Position = GlobalPosition;
        GetTree().CurrentScene.AddChild(bala);
    }
}