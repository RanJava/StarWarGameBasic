using Godot;
using System;

public partial class WinScreen : Control
{
    public override void _Ready()
    {
        GetTree().Paused = true;
    }
}

