using Godot;
using System;

public partial class ProgressBar : Godot.ProgressBar
{
	public void ActualizarBarra(int maximo, int actual)
	{
        MaxValue = maximo;
        Value = actual;
        Visible = actual > 0;
    }
}
