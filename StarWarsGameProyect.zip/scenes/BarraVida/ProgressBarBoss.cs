using Godot;
using System;

public partial class ProgressBarBoss : ProgressBar
{
    public void ActualizarBarraZombie(int maximo, int actual)
    {
        MaxValue = maximo;
        Value = actual;
        Visible = actual > 0;
    }
}
