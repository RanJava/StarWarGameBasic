using Godot;
using System;

public partial class BalaBoss : Area2D
{
    public float velocidadBala = 100f;
    public Vector2 direccion = Vector2.Left;
    public int damage = 1;


    public override void _Ready()
    {
        BodyEntered += Disparado;
    }

    public override void _Process(double delta)
    {
        Position += direccion * velocidadBala * (float)delta;
        if (Position.X < -100 || Position.X > 1500) { QueueFree(); }
    }

    private void Disparado(Node2D cuerpo)
    {
        if (cuerpo is Player jugador)
        {
            jugador.RecibirDano(damage);
            QueueFree();
        }
    }

}
